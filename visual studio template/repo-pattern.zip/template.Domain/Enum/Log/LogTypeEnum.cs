﻿namespace $safeprojectname$.Enum.Log
{
    public enum LogTypeEnum
    {
        OnException = 1,
        Order = 2,
        OrderDeleted = 3,
        SendMail = 4,
    }
}
