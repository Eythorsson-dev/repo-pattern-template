﻿namespace $safeprojectname$.Enum.Log
{
    public enum LogLevelEnum
    {
        Information = 1,
        Warning = 2,
        Error = 3
    }
}
