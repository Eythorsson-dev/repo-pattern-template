﻿namespace $safeprojectname$.Enum.Integration
{
    public enum IntegrationAdditionalDataEnum
    {
        ExampleAuth_PartnerId = 1
    }
}
