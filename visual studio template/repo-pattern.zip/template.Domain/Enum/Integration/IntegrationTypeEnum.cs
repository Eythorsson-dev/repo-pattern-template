﻿namespace $safeprojectname$.Enum.Integration
{
    public enum IntegrationTypeEnum
    {
        ExampleAuth = 1
    }
}
