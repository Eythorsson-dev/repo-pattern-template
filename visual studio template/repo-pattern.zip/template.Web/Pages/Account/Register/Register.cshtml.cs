﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace $safeprojectname$.Pages
{
    public class RegisterModel : PageModel
    {
        public RegisterModel()
        {

        }

        public void OnGet()
        {

        }
    }
}