﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace $safeprojectname$.Pages
{
    public class PasswordResetModel : PageModel
    {
        public PasswordResetModel()
        {

        }

        public void OnGet()
        {

        }
    }
}