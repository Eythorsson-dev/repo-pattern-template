(function () {
    new Vue({
        el: "#app",
        data: function () {
            return {
                date: new Date()
            }
        },
        methods: {

        },
        computed: {

        },
        mounted: function () {

        },
    });
})();