﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using $ext_safeprojectname$.Core.Request.User;
using $ext_safeprojectname$.Core.Service;
using $ext_safeprojectname$.Domain.Model.User;

namespace $safeprojectname$.Pages
{
    [Authorize]
    public class BasePage : PageModel
    {
        protected UserModel CurrentUser { get; private set; }

        protected ServiceContext Services => Core.$ext_safeprojectname$AppContext.Current.Services;

        public virtual void OnGet()
        {
            string url = Request.Path.Value;

            CurrentUser = Services.UserService.FirstOrDefault(new UserFilterRequest { Email = User.Identity.Name });


            if (CurrentUser == null) {
                Response.Redirect("account/login");
                return;
            }
            else if (!CurrentUser.IsEmailConfirmed) {
                if (url != "account/verify-account") {
                    Response.Redirect("account/verify");
                    return;
                }
            }

        }
    }
}
