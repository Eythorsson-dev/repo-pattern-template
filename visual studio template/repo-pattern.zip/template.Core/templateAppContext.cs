﻿using System;
using $safeprojectname$.Service;

namespace $safeprojectname$
{
    public class $ext_safeprojectname$AppContext
    {
        public static $ext_safeprojectname$AppContext Current;

        public readonly ServiceContext Services;

        public $ext_safeprojectname$AppContext(ServiceContext serviceContext)
        {
            if (Current != null)
                throw new InvalidOperationException("TagItAppContext is already initialized");
            Services = serviceContext;
        }
    }
}
