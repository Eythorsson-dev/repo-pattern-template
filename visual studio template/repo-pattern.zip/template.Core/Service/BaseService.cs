﻿using $safeprojectname$.Repository;
using $safeprojectname$.Service.Log;

namespace $safeprojectname$.Service
{
    public abstract class BaseService
    {
        protected readonly IUnitOfWorkProvider UowProvider;
        protected readonly RepositoryFactory RepoFactory;

        protected LogService LogService => Core.$ext_safeprojectname$AppContext.Current.Services.LogService;
        
        public BaseService(IUnitOfWorkProvider uowProvider, RepositoryFactory repoFactory)
        {
            UowProvider = uowProvider;
            RepoFactory = repoFactory;
        }
    }
}
