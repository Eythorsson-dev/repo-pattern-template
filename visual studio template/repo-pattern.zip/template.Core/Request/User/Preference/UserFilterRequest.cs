﻿using $ext_safeprojectname$.Domain.Enum;

namespace $safeprojectname$.Request.User.Preference
{
    public class UserPreferenceFilterRequest
    {
        public long UserId { get; set; }
        public UserPreferenceEnum PreferenceId { get; set; }
    }
}
