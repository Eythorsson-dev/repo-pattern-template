﻿using Microsoft.Extensions.Logging;

namespace $safeprojectname$.Pages
{
    public class OrderModel : BasePage
    {
        public OrderModel()
        {
        
        }

        public override void OnGet()
        {
            base.OnGet();
        }
    }
}