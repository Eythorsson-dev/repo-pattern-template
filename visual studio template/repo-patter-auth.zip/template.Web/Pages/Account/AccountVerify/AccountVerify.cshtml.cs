﻿using Microsoft.AspNetCore.Mvc.RazorPages;

namespace $safeprojectname$.Pages
{
    public class AccountVerifyModel : PageModel
    {
        public AccountVerifyModel()
        {

        }

        public void OnGet()
        {

        }
    }
}