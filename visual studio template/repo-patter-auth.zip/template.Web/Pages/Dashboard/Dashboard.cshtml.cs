﻿using Microsoft.Extensions.Logging;

namespace $safeprojectname$.Pages
{
    public class DashboardModel : BasePage
    {
        public DashboardModel()
        {
        
        }

        public override void OnGet()
        {
            base.OnGet();
        }
    }
}