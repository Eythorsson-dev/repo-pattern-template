﻿using Microsoft.AspNetCore.Mvc;
using $ext_safeprojectname$.Controller;
using $ext_safeprojectname$.Core.Request.User.Preference;
using $ext_safeprojectname$.Core.Service.User.Preference;
using $ext_safeprojectname$.Domain.Enum;
using $ext_safeprojectname$.Domain.Model.User;
using $safeprojectname$.Config.Mapper;
using $safeprojectname$.Dto.Login;
using $safeprojectname$.Dto.Register;
using $safeprojectname$.Dto.User.Preference;

namespace $safeprojectname$.Controller.Account.Preferences
{
    [ApiController]
    [Route("api/user/{userId}/preferences")]
    public class UserPreferencesController : BaseController
    {
        private UserPreferenceService UserPreferenceService => Services.UserPreferenceService;

        [HttpGet("{preferenceId}")]
        public IActionResult GetById([FromRoute] UserPreferenceEnum preferenceId)
        {
            var model = UserPreferenceService.GetUserPreference(CurrentUser.UserId, preferenceId);
            var dto = Mapper.Map<UserPreferenceDto>(model);
            return Ok(dto);
        }

        [HttpPost("{preferenceId}")]
        public IActionResult Update([FromRoute] UserPreferenceEnum preferenceId, [FromBody] UserPreferenceDto dto)
        {
            if (preferenceId != dto.PreferenceId) return BadRequest();

            var model = UserPreferenceService.GetUserPreference(CurrentUser.UserId, preferenceId);
            model.UserPreferenceStr = dto.UserPreferenceStr;
            UserPreferenceService.Update(model);

            return Ok();
        }
    }
}
