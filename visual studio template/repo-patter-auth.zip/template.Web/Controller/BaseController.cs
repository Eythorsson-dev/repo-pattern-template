﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using $ext_safeprojectname$.Core;
using $ext_safeprojectname$.Core.Infrastructure.Filters;
using $ext_safeprojectname$.Core.Request.User;
using $ext_safeprojectname$.Core.Service;
using $ext_safeprojectname$.Core.Service.Log;
using $ext_safeprojectname$.Domain.Model.User;

namespace $ext_safeprojectname$.Controller
{
    [Authorize]
    [ApiController]
    public class BaseController : ControllerBase
    {
        protected ServiceContext Services => $ext_safeprojectname$AppContext.Current.Services;
        protected LogService LogService => Services.LogService;

        protected UserModel CurrentUser => GetCurrentUser();

        private UserModel _currentUser;
        private UserModel GetCurrentUser()
        {
            if (_currentUser == null && User != null)
            {
                var user_req = new UserFilterRequest { UserId = long.Parse(User.FindFirst(ClaimTypes.NameIdentifier).Value) };
                _currentUser = Services.UserService.FirstOrDefault(user_req);
            }
            return _currentUser;
        }
    }
}
