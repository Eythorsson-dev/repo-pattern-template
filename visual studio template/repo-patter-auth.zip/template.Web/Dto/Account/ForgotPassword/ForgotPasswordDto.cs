﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace $safeprojectname$.Dto.Account.ForgotPassword
{
    public class ForgotPasswordDto
    {
        public string Email { get; set; }
    }
}
