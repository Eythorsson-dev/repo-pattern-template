﻿namespace $safeprojectname$.Dto.Account.ResetPassword
{
    public class ResetPasswordDto
    {
        public string Email { get; set; }
        public string Code { get; set; }
        public string Password { get; set; }
    }
}
