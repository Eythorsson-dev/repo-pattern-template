﻿using AutoMapper;
using $ext_safeprojectname$.Domain.Model.Order;
using $ext_safeprojectname$.Domain.Model.User;
using $ext_safeprojectname$.Domain.Model.User.Preference;
using $safeprojectname$.Dto.Order;
using $safeprojectname$.Dto.User;
using $safeprojectname$.Dto.User.Preference;

namespace $safeprojectname$.Config.Mapper.Profiles
{
    public class DefaultMapperProfile : Profile
    {
        public DefaultMapperProfile()
        {
            // ARTICLE
            //CreateMap<ArticleModel, LookupItemDto>()
            //   .ForMember(x => x.Id, y => y.MapFrom(m => m.ArticleId))

            // USER
            CreateMap<UserPreferenceModel, UserPreferenceDto>().ReverseMap();
            CreateMap<UserModel, UserDto>().ReverseMap();

            // ORDER
            CreateMap<OrderModel, OrderDto>().ReverseMap();
        }
    }
}
