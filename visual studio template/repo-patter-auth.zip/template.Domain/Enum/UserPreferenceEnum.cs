﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$.Enum
{
    public enum UserPreferenceEnum
    {
        DASHBOARD_CLOCK = 1
    }
}
