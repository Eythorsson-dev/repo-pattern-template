﻿using $ext_safeprojectname$.Domain.Enum.Integration;

namespace $safeprojectname$.Request.Integration
{
    public class IntegrationFilterRequest : BaseRequestPaged<IntegrationOrderByEnum>
    {
        public long IntegrationId { get; set; }
        public IntegrationTypeEnum IntegrationType { get; set; }
    }

    public enum IntegrationOrderByEnum
    {
        IntegrationType = 1 
    }
}
