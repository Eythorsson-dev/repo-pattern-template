﻿using Newtonsoft.Json;

namespace $safeprojectname$.ExternalApi.ExampleAuthApi.Dto.Data
{
    internal class DataRequestDto
    {

        [JsonProperty("product_no")]
        public string ProductNo { get; set; }
    }
}
